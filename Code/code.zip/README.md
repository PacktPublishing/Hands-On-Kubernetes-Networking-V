# localkube

This repository allows you to bootstrap a Kubernetes cluster locally with [Vagrant](https://www.vagrantup.com/) 
and [Ansible](https://www.ansible.com/). It is based on the initial code shared in a 
[blog post](https://kubernetes.io/blog/2019/03/15/kubernetes-setup-using-ansible-and-vagrant/) published on 
[the official Kubernetes blog](https://kubernetes.io/blog/).
